import java.util.Scanner;
public class CabFree {
    public static void main(String arg[]) {
        
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Enter distance in KM:");
        double km = sc.nextDouble();
        
        double fare = 50 + (km * 12);
        
        System.out.println("Total Fare:" + fare);
    }
}
