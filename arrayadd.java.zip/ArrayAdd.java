import java.util.Arrays;

public class ArrayAdd {
    public static void main(String[] args) {

        int a[] = {1, 2, 3, 4, 5};
        int b[] = {5, 4, 3, 2, 1};

        int c[] = new int[a.length];

        // Adding arrays
        for (int i = 0; i < a.length; i++) {
            c[i] = a[i] + b[i];
        }

        // Printing result
        System.out.println("First Array  : " + Arrays.toString(a));
        System.out.println("Second Array : " + Arrays.toString(b));
        System.out.println("Sum Array    : " + Arrays.toString(c));
    }
}
