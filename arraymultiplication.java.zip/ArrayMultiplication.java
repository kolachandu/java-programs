import java.util.Arrays;

public class ArrayMultiplication {
    public static void main(String[] args) {

        int a[][] = {
                {4, 5, 6},
                {1, 2, 3},
                {7, 8, 9}
        };

        int b[][] = {
                {1, 3, 5},
                {2, 4, 6},
                {3, 6, 8}
        };

        int c[][] = new int[3][3];

        // Matrix Multiplication
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                for (int k = 0; k < 3; k++) {
                    c[i][j] += a[i][k] * b[k][j];
                }
            }
        }

        // Print Result Matrix
        System.out.println("Result Matrix:");

        for (int i = 0; i < 3; i++) {
            System.out.println(Arrays.toString(c[i]));
        }
    }
}