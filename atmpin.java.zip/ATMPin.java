/*https://www.onlinegdb.com/#editor_1*****************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
public class ATMPin {
    public static void main(String arg[]) {
        Scanner sc = new Scanner(System.in);
        int correctPin = 1234;
        System.out.print("Enter ATM PIN:");
        int pin =sc.nextInt();
        if(pin == correctPin) {
            System.out.println("Access Granted");
        }
        else {
            System.out.println("invalid PIN");
            
        }
	}
}
