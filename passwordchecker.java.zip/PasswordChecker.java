import java.util.Scanner;
public class PasswordChecker {
    public static void main(String arg[]) {
        
        Scanner sc = new Scanner(System.in);
        String password = sc.nextLine();
        if(password.length()>= 8) {
            System.out.print("Strong Password");
        }
        else {
            System.out.println("Weak Password");
        }
    }
}