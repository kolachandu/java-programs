import java.util.Scanner;
public class DiscountBill
{
    public static void main(String arg[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter purchase amount");
        double amount = sc.nextInt();
        double finalAmount;
        if(amount>5000){
            finalAmount=amount - (amount*0.20);
        }
    else {
        finalAmount=amount - (amount*0.10);
    }
    
    System.out.println("Final Bill:"+finalAmount);
}
}
